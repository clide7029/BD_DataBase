# -*- coding: utf-8 -*-
from node.testing.fullmapping import FullMappingTester
